<!DOCTYPE html>
<html>

<!-- Mirrored from themexriver.com/tfhtml/finano/index-5.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 17 Jan 2019 02:00:56 GMT -->
<head>
<meta charset="utf-8">
<title>Hometeacher is the learning platform that all the user to earn income</title>
<!-- Stylesheets -->
<link href="css/bootstrap.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">
<link href="css/responsive.css" rel="stylesheet">

<link rel="shortcut icon" href="images/logo.jpg" type="image/x-icon">
<link rel="icon" href="images/logo.jpg" type="image/x-icon">

<!-- Responsive -->
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">

<!--[if lt IE 9]><script src="https://cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.3/html5shiv.js"></script><![endif]-->
<!--[if lt IE 9]><script src="js/respond.js"></script><![endif]-->
</head>

<body>

<div class="page-wrapper">
 	
    <!-- Preloader -->
    <div class="preloader"></div>
 	
    <!-- Main Header-->
    <header class="main-header header-style-five">
    	
		<!--Header Top-->
        {{-- <div class="header-top">
            <div class="auto-container">
                <div class="inner-container clearfix">
                    <div class="top-left">
                        <ul class="contact-list clearfix">
                            <li><i class="fa fa-envelope-o"></i> info@hometeacher.ng</li>
                            <li><i class="fa fa-phone"></i><a href="#">+123 814 065 8029</a></li>
							<li><i class="fa fa-map-marker"></i><a href="#">4 Atiku Abubaka way, Uyo, AKS, Nigeria</a></li>
                        </ul>
                    </div>
                    <div class="top-right">
					
                        
						<!--Language-->
						
						
                    </div>
                </div>
            </div>
        </div> --}}
        <!-- End Header Top -->
		
    	<!--Header-Upper-->
        <div class="header-upper">
        	<div class="auto-container">
            	<div class="clearfix">
                	
                	<div class="pull-left logo-box">
                    	<div class="logo"><a href="https://home.hometeacher.ng"><img style="width: 90%; height: 42px;" src="images/logo.jpg" alt="" title=""></a></div>
                    </div>
		
                   	
                   	<div class="nav-outer clearfix">
                    
						<!-- Main Menu -->
						<nav class="main-menu navbar-expand-md">
							<div class="navbar-header">
								<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
									<span class="icon-bar"></span>
									<span class="icon-bar"></span>
									<span class="icon-bar"></span>
								</button>
							</div>

							<div class="navbar-collapse collapse clearfix" id="navbarSupportedContent">
								<ul class="navigation clearfix">
									<li class="current"><a href="https://home.hometeacher.ng">Home</a></li>
									<li><a href="https://hometeacher.ng/about">About Us</a></li>
									
									
									<li><a href="primaryclasses">Primary Hometeacher</a></li>
									<li><a href="secondaryclasses">Secondary Hometeacher</a></li>

									<li><a href="https://hometeacher.ng/contact">Contact us</a></li>
									<li><a href="https://home.hometeacher.ng/buyer/login">Login</a></li>

									
								</ul>
							</div>
							
						</nav>
						
						<!--Outer Box-->
						<div class="outer-box">
							
							<!--Search Box-->
							{{-- <div class="search-box-outer">
								<div class="dropdown">
									<button class="search-box-btn dropdown-toggle" type="button" id="dropdownMenu3" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><span class="fa fa-search"></span></button>
									<ul class="dropdown-menu pull-right search-panel" aria-labelledby="dropdownMenu3">
										<li class="panel-outer">
											<div class="form-container">
												<form method="post" action="">
													<div class="form-group">
														<input type="search" name="field-name" value="" placeholder="Search Here" required>
														<button type="submit" class="search-btn"><span class="fa fa-search"></span></button>
													</div>
												</form>
											</div>
										</li>
									</ul>
								</div>
							</div> --}}
							
						</div>
						
					</div>
					
                </div>
            </div>
        </div>
        <!--End Header Upper-->
        
		<!--Sticky Header-->
        <div class="sticky-header">
        	<div class="auto-container clearfix">
            	<!--Logo-->
            	<!-- <div class="logo pull-left">
                	<a href="https://home.hometeacher.ng" class="img-responsive"><img style="width: 80%; margin-top: 10px; height: 35px;" src="images/logo.jpg" alt="" title=""></a>
                </div> -->
                
                <!--Right Col-->
                <div class="right-col pull-right">
                	<!-- Main Menu -->
                    <nav class="main-menu navbar-expand-md">
                        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent1" aria-controls="navbarSupportedContent1" aria-expanded="false" aria-label="Toggle navigation">
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                        
                        <div class="navbar-collapse collapse clearfix" id="navbarSupportedContent1">
						<ul class="navigation clearfix">
							<li class="current"><a href="https://home.hometeacher.ng/">Home</a></li>
							<li><a href="https://hometeacher.ng/about">About Us</a></li>
							
							
							<li><a href="primaryclasses">Primary Hometeacher</a></li>
							<li><a href="secondaryclasses">Secondary Hometeacher</a></li>

							<li><a href="https://hometeacher.ng/contact">Contact us</a></li>
						</ul>
                        </div>
                    </nav><!-- Main Menu End-->
                </div>
                
            </div>
        </div>
        <!--End Sticky Header-->
		
    </header>
    <!--End Main Header -->

	<body>
<!--Page Title-->
{{-- <section class="page-title" style="background-image:url(images/resource/home.jpg)">
    	<div class="auto-container">
			<div class="content">
				<h1>Home Teacher <span></span></h1>
				<ul class="page-breadcrumb">
					<li><a href="login">Home</a></li>
					<li>Pages</li>
					<li>Primary Schools</li>
				</ul>
			</div>
        </div>
    </section> --}}


    
		<!-- News Section Two -->
	<section class="news-section-two style-two" style="margin-bottom: 50px;">
		<div class="auto-container">
			<!-- Sec Title -->
			{{-- <div class="sec-title-three">
				<div class="clearfix">
					<div class="pull-left">
						<h2>Home teaching the real Educational tech aid</h2>
					</div>
					
				</div>
			</div> --}}
			
			<div class="row clearfix">
				
				<!-- News Block Two -->
				<div class="news-block-two red col-lg-4 col-md-6 col-sm-12">
					<div class="inner-box wow fadeInUp" data-wow-delay="0ms" data-wow-duration="1500ms">
						<div class="image">
							<img style="height: 250px;" src="images/resource/teach1.jpg" alt="" />
							<div class="overlay-box">
								<a href="images/resource/teach1.jpg" data-fancybox="news" data-caption="" class="plus flaticon-plus-symbol"></a>
							</div>
						</div>
						<div class="lower-content">
							<h5><a href="js1">JSS 1</a></h5>
							<a href="js1" class="theme-btn btn-style-fourteen">View</a>
						</div>
					</div>
				</div>


				<!-- News Block Two -->
				<div class="news-block-two red col-lg-4 col-md-6 col-sm-12">
					<div class="inner-box wow fadeInUp" data-wow-delay="0ms" data-wow-duration="1500ms">
						<div class="image">
							<img style="height: 250px;" src="images/resource/teach1.jpg" alt="" />
							<div class="overlay-box">
								<a href="images/resource/teach1.jpg" data-fancybox="news" data-caption="" class="plus flaticon-plus-symbol"></a>
							</div>
						</div>
						<div class="lower-content">
							
							<h5><a href="jss2">JSS 2</a></h5>
							<a href="jss2" class="theme-btn btn-style-fourteen">View</a>
						</div>
					</div>
				</div>

				<!-- News Block Two -->
				<div class="news-block-two red col-lg-4 col-md-6 col-sm-12">
					<div class="inner-box wow fadeInUp" data-wow-delay="0ms" data-wow-duration="1500ms">
						<div class="image">
							<img style="height: 250px;" src="images/resource/teach1.jpg" alt="" />
							<div class="overlay-box">
								<a href="images/resource/teach1.jpg" data-fancybox="news" data-caption="" class="plus flaticon-plus-symbol"></a>
							</div>
						</div>
						<div class="lower-content">
							
							<h5><a href="jss3">JSS 3</a></h5>
							
							<a href="jss3" class="theme-btn btn-style-fourteen">View</a>
						</div>
					</div>
				</div>


                <!-- News Block Two -->
				<div class="news-block-two red col-lg-4 col-md-6 col-sm-12" style="margin-top: 30px">
					<div class="inner-box wow fadeInUp" data-wow-delay="0ms" data-wow-duration="1500ms">
						<div class="image">
							<img style="height: 250px;" src="images/resource/teach1.jpg" alt="" />
							<div class="overlay-box">
								<a href="images/resource/teach1.jpg" data-fancybox="news" data-caption="" class="plus flaticon-plus-symbol"></a>
							</div>
						</div>
						<div class="lower-content">
							
							<h5><a href="ss1">SSS 1</a></h5>
							
							<a href="ss1" class="theme-btn btn-style-fourteen">View</a>
						</div>
					</div>
				</div>


                <!-- News Block Two -->
				<div class="news-block-two red col-lg-4 col-md-6 col-sm-12" style="margin-top: 30px">
					<div class="inner-box wow fadeInUp" data-wow-delay="0ms" data-wow-duration="1500ms">
						<div class="image">
							<img style="height: 250px;" src="images/resource/teach1.jpg" alt="" />
							<div class="overlay-box">
								<a href="images/resource/teach1.jpg" data-fancybox="news" data-caption="" class="plus flaticon-plus-symbol"></a>
							</div>
						</div>
						<div class="lower-content">
							<h5><a href="ss2">SSS 2</a></h5>
							<a href="ss2" class="theme-btn btn-style-fourteen">View</a>
						</div>
					</div>
				</div>
                

                <!-- News Block Two -->
				<div class="news-block-two red col-lg-4 col-md-6 col-sm-12" style="margin-top: 30px">
					<div class="inner-box wow fadeInUp" data-wow-delay="0ms" data-wow-duration="1500ms">
						<div class="image">
							<img style="height: 250px;" src="images/resource/teach1.jpg" alt="" />
							<div class="overlay-box">
								<a href="images/resource/teach1.jpg" data-fancybox="news" data-caption="" class="plus flaticon-plus-symbol"></a>
							</div>
						</div>
						<div class="lower-content">
							<h5><a href="ss3">SSS 3</a></h5>
							<a href="ss3" class="theme-btn btn-style-fourteen">View</a>
						</div>
					</div>
				</div>

		</div>
	</section>





<!--Main Footer-->
<footer class="main-footer style-three">
	<div class="auto-container">
		<!--Widgets Section-->
		<div class="widgets-section">
			<div class="row clearfix">
				
				<!--Column-->
				<div class="big-column col-lg-6 col-md-12 col-sm-12">
					<div class="row clearfix">
					
						<!--Footer Column-->
						<div class="footer-column col-lg-7 col-md-6 col-sm-12">
							<div class="footer-widget logo-widget">
								<div class="logo">
									<a href="index"><img src="images/logo.jpg" alt="" /></a>
								</div>
								<div class="text">Please you contact us below the address</div>
								<ul class="list-style-two">
									<li><span class="icon fa fa-phone"></span> +123 814 065 8029</li>
									<li><span class="icon fa fa-envelope"></span> info@hometeacher.ng</li>
									<li><span class="icon fa fa-home"></span>4 Atiku Abubakka way, Uyo,<br> AKS, Nigeria </li>
								</ul>
							</div>
						</div>
						
						<!--Footer Column-->
						<div class="footer-column col-lg-5 col-md-6 col-sm-12">
							<div class="footer-widget links-widget">
								<h4>Links</h4>
								<ul class="list-link">
									<li><a href="https://hometeacher.ng">Home</a></li>
									<li><a href="primaryhometeacher">Primary Subjects</a></li>
									<li><a href="about">About us</a></li>
									<li><a href="productadverts">Product Ads</a></li>
									
								</ul>
							</div>
						</div>

					</div>
				</div>
				
				<!--Column-->
				<div class="big-column col-lg-6 col-md-12 col-sm-12">
					<div class="row clearfix">
					
						<!--Footer Column-->
						<div class="footer-column col-lg-6 col-md-6 col-sm-12">
							<div class="footer-widget links-widget">
								<h4>Support</h4>
								<ul class="list-link">
									<li><a href="contact">Contact Us</a></li>
									<li><a href="contact">Submit a Ticket</a></li>
									<li><a href="contact">Visit Knowledge Base</a></li>
									
								</ul>
							</div>
						</div>
						
						<!--Footer Column-->
						<div class="footer-column col-lg-6 col-md-6 col-sm-12">
						<div class="footer-widget links-widget">
								<h4>Links</h4>
								<ul class="list-link">
									<li><a href="schooladverts">Schoolads</a></li>
									<li><a href="secontaryhometeacher">Secondary Subjects</a></li>
									<li><a href="contact">Support System</a></li>
									<li><a href="#">Refund Policy</a></li>
									<li><a href="#">Professional Services</a></li>
								</ul>
							</div>

							
						</div>
						
					</div>
				</div>
				
			</div>
		</div>
	</div>
	<!-- Footer Bottom -->
	<div class="footer-bottom">
		<div class="auto-container">
			<div class="row clearfix">
				
				<!-- Copyright Column -->
				<div class="copyright-column col-lg-6 col-md-6 col-sm-12">
					<div class="copyright">2022 &copy; All rights reserved by <a href="#">Hometeacher.ng</a></div>
				</div>
				
				<!-- Social Column -->
				<div class="social-column col-lg-6 col-md-6 col-sm-12">
					<ul>
						<li class="follow">Follow us: </li>
						<li><a href="#"><span class="fa fa-facebook-square"></span></a></li>
						<li><a href="#"><span class="fa fa-twitter-square"></span></a></li>
						<li><a href="#"><span class="fa fa-linkedin-square"></span></a></li>
						<li><a href="#"><span class="fa fa-google-plus-square"></span></a></li>
						<li><a href="#"><span class="fa fa-rss-square"></span></a></li>
					</ul>
				</div>
				
			</div>
		</div>
	</div>
</footer>

</div>
<!--End pagewrapper-->

<script src="js/jquery.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.mCustomScrollbar.concat.min.js"></script>
<script src="js/jquery.fancybox.js"></script>
<script src="js/appear.js"></script>
<script src="js/owl.js"></script>
<script src="js/wow.js"></script>
<script src="js/jquery-ui.js"></script>
<script src="js/main.js"></script>
<!--Google Map APi Key-->
<script src="http://maps.google.com/maps/api/js?key=AIzaSyDTPlX-43R1TpcQUyWjFgiSfL_BiGxslZU"></script>
<script src="js/map-script.js"></script>
<!--End Google Map APi-->

</body>

<!-- Mirrored from themexriver.com/tfhtml/finano/index-5.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 17 Jan 2019 02:01:53 GMT -->
</html>